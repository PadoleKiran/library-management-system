from Book_details_for_user import Book_detail_for_user
from Book_details_for_user import Book_detail_search_according_to_requirement
from borrow_book import borrow_book
from user_borrow import user_borrow


def user_main_page(user_name):
    print("******************************************************************************")
    print("                            Welcome in Library                                ")
    print("******************************************************************************")

    while True:
        print("Do you want to search book :                               press 1 " +
              "\nDo you want to see our all book collection :               press 2 " +
              "\nDo you want to see your last brow items form library :     press 3" +
              "\nBorrow Book :                                              press 4" +
              "\nExit :                                                     press 5")

        choice = int(input("Enter your choice : "))

        match choice:
            case 1:
                Book_detail_for_user()
            case 2:
                Book_detail_search_according_to_requirement()
            case 3:
                user_borrow(user_name)
            case 4:
                borrow_book(user_name)
            case 5:
                exit(0)
            case _:
                print("Pleas Enter correct number !!")


# user_main_page()
