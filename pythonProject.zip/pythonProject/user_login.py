# this code is for user login

import pymongo

from user_main import user_main_page


def login_user(username, password):
    con = pymongo.MongoClient()  # making connection with mongodb
    Library = con['Library']  # database name
    users = Library.users  # collection name

    user = users.find_one({'username': username})
    if user is None:
        return False

    if password == user['password']:
        return True
    else:
        return False


def user_login():
    print("***************************** Welcome To Login Page **************************")
    username = input('Enter username: ')
    password = input('Enter password: ')

    user_name = username

    is_logged_in = login_user(username.lower(), password.lower())
    if is_logged_in:
        print("******************************************************************************")
        print('User successfully logged in.')
        print("******************************************************************************")
        user_main_page(user_name)  # this is main functionality of user

    else:
        print("******************************************************************************")
        print('Incorrect username or password.')
        print("******************************************************************************")
