# import pymongo
#
# con = pymongo.MongoClient()  # making connection with mongodb
# Library = con['Library']  # database name
# books = Library.books  # collection name
#
# # Calculate the number of entries in the `books` collection using the `count_documents()` method
# num_entries = books.count_documents({})
#
# book_id = "B10" + str(num_entries + 1)
#
# print("book id is " + book_id)
#
# print(f"The number of entries in the `books` collection is: {num_entries}")


# import pymongo
# from pip._internal.utils.misc import tabulate
#
# con = pymongo.MongoClient()  # making connection with mongodb
# Library = con['Library']  # database name
# books = Library.books  # collection name
#
# # Find all books in the collection
# cursor = books.find()
#
# # Create a table to store the book details
# table = []
# for book in cursor:
#     row = [book['_id'], book['title'], book['author'], book['genre'], book['publication_year']]
#     table.append(row)
#
# # Print the table
# print(tabulate(table, headers=['ID', 'Title', 'Author', 'Genre', 'publication_year']))



# import pymongo
# from pip._internal.utils.misc import tabulate
#
# con = pymongo.MongoClient()  # making connection with mongodb
# Library = con['Library']  # database name
# books = Library.books  # collection name
#
# # Calculate the number of entries in the `books` collection using the `count_documents()` method
# num_entries = books.count_documents({})
#
# # Create a unique book id
# book_id = "B10" + str(num_entries + 1).zfill(2)
#
# print("book id is " + book_id)
#
# print(f"The number of entries in the `books` collection is: {num_entries}")
#
# # Find all books in the collection
# cursor = books.find()
#
# # Create a table to store the book details
# table = []
# for book in cursor:
#     row = [book['book_id'], book['title'], book['author'], book['genre'], book['publication_year']]
#     table.append(row)
#
# # Print the table
# # print(tabulate(table, headers=['book_id', 'Title', 'Author', 'Genre', 'publication_year']))
# print()