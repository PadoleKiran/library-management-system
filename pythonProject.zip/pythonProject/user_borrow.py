# this code is for display borrow items by user

import pymongo


def user_borrow(user_name):
    print("this is user borrow function")
    con = pymongo.MongoClient()  # making connection with mongodb
    Library = con['Library']  # database name
    users = Library.users  # collection name

    borrow = users.find({'username': user_name})

    if borrow is None:
        return False

    for user in borrow:
        if user['borrow']:
            print("The borrow items are:")
            for item in user['borrow']:
                print(item)
        else:
            print("******************************************************************************")
            print("You have not borrowed any books.")
            print("******************************************************************************")
