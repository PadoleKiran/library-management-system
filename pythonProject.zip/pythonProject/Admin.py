def Admin_functionality():
    pass
