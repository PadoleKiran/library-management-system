import pymongo


def user_borrow(user_name):
    print("this is user borrow function")
    con = pymongo.MongoClient()  # making connection with mongodb
    Library = con['Library']  # database name
    users = Library.users  # collection name

    borrow = users.find({'username': user_name})

    if borrow is None:
        return False

    for user in borrow:
        if user['borrow']:
            print("The borrow items are:")
            for item in user['borrow']:
                print(item)
        else:
            print("You have not borrowed any books.")


if __name__ == '__main__':
    user_name = 'krish'
    user_borrow(user_name)
